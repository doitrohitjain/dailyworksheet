<?php

namespace App\Http\Controllers;

use App\Models\Report;
use App\Models\Project;
use App\Models\Worksheet;
use App\Models\User;
use Illuminate\Http\Request;
use App\Exports\WorksheetsExport;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends Controller
{
    /**
     * Display a listing of the resource.
     */
	public function index()
    { 
		
        // Fetch all reports with the admin who generated them
        $reports = Report::with('generatedBy')->latest()->paginate(10);
		$projects = [];
		if(auth()->user()->role == 'admin'){
			$projects = Project::latest()->pluck("title","id");
		}else{
			$projects_id = auth()->user()->projects_id;
			$projects_id = json_decode($projects_id);
			$projects = Project::whereIn('id',$projects_id)->latest()->pluck("title","id");	
		} 
        return view('reports.index', compact('reports','projects'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    
	public function downloadExcel(Request $request) {
		$request->validate([
			'start_date' => 'required|date',
			'end_date' => 'required|date|after_or_equal:start_date',
		]);
		if(auth()->user()->role == 'admin'){
			
		}else{
			$conditions['user_id'] = auth()->user()->id;
		}
		$querys['start_date'] = $request->start_date;
		$querys['end_date'] = $request->end_date;
		$querys['name'] = @$request->name;
		$querys['email'] = @$request->email;
		$querys['projects_id'] = @$request->projects_id;
		$fileName = 'worksheet_' . $request->start_date . "_". $request->end_date ;
		
		return Excel::download(new WorksheetsExport($querys),$fileName.'_' . date("d-m-Y") .'.xlsx');
		 
		// $worksheets = Worksheet::whereBetween('date', [$request->start_date, $request->end_date])
							   // ->get(); 
							   
		// dd($worksheets);
		// return redirect()->back()->with('success', 'Report Excel has been exported successfully.');
	}
	
	
	public function employee_listing() { 
		echo "sdfasdf";die;
		// $users = User::paginate(10);
		// dd($users);
		// return view('reports.employee_listing', compact('users'));
	}
	
	public function store(Request $request) {
		$request->validate([
			'start_date' => 'required|date',
			'end_date' => 'required|date|after_or_equal:start_date',
		]);
		
		$worksheets = Worksheet::whereBetween('date', [$request->start_date, $request->end_date])
							   ->get();

		$reportDetails = $worksheets->groupBy('user_id')->map(function ($tasks, $userId) {
			return [
				'user' => User::find($userId)->name,
				'tasks' => $tasks->count(),
				'completed' => $tasks->where('status', 'completed')->count(),
			];
		});

		Report::create([
			'start_date' => $request->start_date,
			'end_date' => $request->end_date,
			'generated_by' => auth()->id(),
			'details' => $reportDetails->toJson(),
		]);

		return redirect()->back()->with('success', 'Report generated successfully.');
	}


    /**
     * Display the specified resource.
     */
    public function show(Report $report,$id)
    {
        // Fetch the report along with the admin who generated it
        $report = Report::with('generatedBy')->findOrFail($id);

        // Pass the report details to the view
        return view('reports.show', compact('report'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Report $report)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Report $report)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Report $report)
    {
        //
    }
}
