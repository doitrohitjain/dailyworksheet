<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AdminController;
use App\Http\Controllers\WorksheetController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProjectController;




Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/employee_register', [App\Http\Controllers\HomeController::class, 'employee_register'])->name('employee_register');
Route::post('/employee_store', [App\Http\Controllers\HomeController::class, 'employee_store'])->name('employee_store');



Route::get('/clear-cache', function() { 
	Artisan::call('cache:clear');
	Artisan::call('route:clear');
	Artisan::call('config:cache');
	Artisan::call('view:clear');
	Artisan::call('optimize:clear');
	//Artisan::call('key:generate');
	return Redirect::back()->withErrors(['message' => 'Cache cleared!']);
	//return "<h1><center>Cache cleared !</center></h1>";
}); 

Route::get('/routes-list', function () {
	$routes = collect(Route::getRoutes())->map(function ($route) {
		return [
			'uri' => $route->uri(),
			'method' => implode('|', $route->methods()),
			'name' => $route->getName(),
			'action' => $route->getActionName(),
			'middleware' => $route->gatherMiddleware(),
		];
	});

	return view('routes.routes', ['routes' => $routes]);
});

Route::middleware(['auth'])->group(function () {
    Route::get('/', [WorksheetController::class, 'index'])->name('dashboard');

    // Worksheet routes
    Route::resource('worksheets', WorksheetController::class);
	Route::resource('projects', ProjectController::class);
	
	// Route::get('/projects/{id}', [ProjectController::class, 'show'])->name('projects.show');
	Route::any('/projects/destroy/{id}', [HomeController::class, 'destroy'])->name('projects.destroy');
	// Route::post('/store', [HomeController::class, 'store'])->name('projects.store');
	
	Route::resource('users', AdminController::class); 
	Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
	Route::get('/reports/{id}', [ReportController::class, 'show'])->name('reports.show');
	Route::post('/reports/downloadExcel', [ReportController::class, 'downloadExcel'])->name('reports.downloadExcel');
	Route::any('/home/employee_listing', [HomeController::class, 'employee_listing'])->name('home.employee_listing');
	Route::any('/home/destroy/{id}', [HomeController::class, 'destroy'])->name('home.destroy');
	Route::post('/store', [ReportController::class, 'store'])->name('reports.store');
		
		
	Route::post('/master_reports/downloadExcel', [MasterReportController::class, 'downloadExcel'])->name('master_reports.downloadExcel'); 
	
	
    // Admin-specific routes
    Route::middleware('can:admin-access')->group(function () {
        // Route::resource('users', AdminController::class);
        // Route::resource('reports', ReportController::class);
		
		// Route::resource('users', AdminController::class); 
		// Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
		// Route::get('/reports/{id}', [ReportController::class, 'show'])->name('reports.show');
		// Route::post('/reports', [ReportController::class, 'store'])->name('reports.store');
    });
});
