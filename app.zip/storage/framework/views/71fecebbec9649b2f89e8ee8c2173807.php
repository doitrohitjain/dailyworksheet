<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
	 
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
		rel="stylesheet">
	<!-- CKEditor 5 Stable CDN -->
	<script src="https://cdn.ckeditor.com/ckeditor5/39.0.2/classic/ckeditor.js"></script>

	
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
	<link rel="icon" type="image/x-icon" href="/images/logo.png">
	<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
	<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm headerNav">
            <div class="container">
                <a class="navbar-brand main_menu_navbar_brand" href="<?php echo e(url('/')); ?>">
					<img src="<?php echo e(asset('images/logo.png')); ?>" width="40" height="40" alt="Logo">
					 <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto main_menu_navbar_brand">
                        <!-- Authentication Links --> 
						<?php if(auth()->guard()->guest()): ?>
							<?php if(Route::currentRouteName() === 'login'): ?>
							<?php else: ?> 
								<?php if(Route::has('login')): ?>
									<li class="nav-item">
										<a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
									</li>
								<?php endif; ?>
							<?php endif; ?> 
                        <?php else: ?>
							<?php if(Route::has('dashboard')): ?>
								<li class="nav-item">
									<a class="nav-link mainitem nav-link-active" href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Daily Worksheet')); ?></a>
								</li>
							<?php endif; ?>
					 
							<?php if(auth()->user()->role == 'admin'): ?>
								<?php if(Route::has('employee_register')): ?>
									<li class="nav-item">
										<a class="nav-link mainitem" href="<?php echo e(route('employee_register')); ?>"><?php echo e(__('Staff Registration')); ?></a>
									</li>
								<?php endif; ?>  
							<?php endif; ?> 
							<li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link mainitem dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                   Reports
                                </a> 
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
									
									<?php if(Route::has('reports.index')): ?>
										<a class="nav-link" href="<?php echo e(route('reports.index')); ?>"><?php echo e(__(' Worksheets Report')); ?></a>
									<?php endif; ?> 
									<?php if(auth()->user()->role == 'admin'): ?>
									<?php if(Route::has('home.employee_listing')): ?> 
										<a class="nav-link " href="<?php echo e(route('home.employee_listing')); ?>"><?php echo e(__('Staff Report')); ?></a>
									<?php endif; ?>
									<?php endif; ?>
                                </div>
                            </li>
							
						 
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link mainitem dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a> 
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
									<a class="dropdown-item"href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
										<?php echo e(ucfirst(Auth::user()->role)); ?>

									</a> 
									<a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>  
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
		
	 
		<footer class="bg-dark text-white py-5">
			<div class="container">
				<div class="row">
					<!-- Column 1: About -->
					<div class="col-md-8">
						<h5>About Us</h5>
						<p> 
							Welcome to our Daily Worksheet, Employee, and Report Management System! Our platform is designed to streamline your workplace operations, making task management, employee tracking, and reporting easier and more efficient. Whether you're a small business or a growing organization, we provide a user-friendly solution tailored to meet your needs.  
							<br>
							Join us today and experience the future of workplace efficiency! 
						</p>
					</div> 
				   
					<!-- Column 3: Contact -->
					<div class="col-md-4">
						<h5>Contact Us</h5>
						<p>
							<i class="bi bi-geo-alt-fill"></i> IT Building,Yojana Bhawan, Tilak Marg,  <br>
							<i class="bi bi-telephone-fill"></i> C-Scheme Jaipur-302005 (Raj), INDIA  
						</p>
					</div>
				</div>
				<hr class="bg-white">
				<div class="text-center">
					<p class="mb-0">&copy; <?php echo e(date("Y")); ?> Designed, Developed, and Maintained by DOITC. All rights reserved.</p>
				</div>
			</div>
		</footer> 
    </div>
	<style>
		 .mandatory {
		  color: red;
		}
		
	</style>  
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.multiselect').select2({
            placeholder: "Please Select",
            allowClear: true
        });
    });
</script>

<script>
	if (document.querySelector('.editor-class')) {
			let editorInstance;

		// Initialize CKEditor
		ClassicEditor
			.create(document.querySelector('.editor-class'))
			.then(editor => {
				editorInstance = editor;
			})
			.catch(error => {
				console.error(error);
			});

		// jQuery form submission validation
		$('#myForm').on('submit', function (e) {
			// Get CKEditor content
			const content = editorInstance.getData().trim();

			// Check if the content is empty
			if (content === '') {
				e.preventDefault(); // Prevent form submission
				Swal.fire({
					icon: 'error',
					title: 'Validation Error',
					text: 'The In-depth Task Explanation is required!',
				});
			}
		});
	}
</script>
	
	
  <script>
    // Initialize CKEditor for the specific class
    // document.querySelectorAll('.editor-class').forEach(editorElement => {
		// ClassicEditor.create(editorElement)
		// .catch(error => console.error(error));
    // });
	window.onload = function() {
		var today = new Date().toISOString().split('T')[0];
		if (document.querySelector('.date')) {
			document.querySelector('.date').setAttribute("max", today);
			document.querySelector(".date").setAttribute("value", today);
		}

		if (document.querySelector('.end_date')) {
			document.querySelector('.end_date').setAttribute("max", today);
			document.querySelector(".end_date").setAttribute("value", today);
		} 		
	};
	 
  </script>
</body>
</html>
<?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/layouts/app.blade.php ENDPATH**/ ?>