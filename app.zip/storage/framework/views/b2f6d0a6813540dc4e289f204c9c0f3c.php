<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Staff</h1>
 
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Sr.No.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e(ucfirst($user->role)); ?></td>
                <td>  
					<form action="<?php echo e(route('home.destroy', Crypt::encrypt($user->id))); ?>" method="POST" style="display:inline-block;">
						<?php echo csrf_field(); ?>
						<?php echo method_field('DELETE'); ?>
						<button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
					</form>
				</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td colspan="10">
					<?php echo e($users->withQueryString()->links('elements.paginater')); ?>

				</td>
			</tr>
			
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/home/employee_listing.blade.php ENDPATH**/ ?>