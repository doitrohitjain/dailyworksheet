<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>
		<?php if(Auth::user()->role == 'admin'): ?>
		<?php else: ?>
			My
		<?php endif; ?>
			Daily Worksheets
		</h1>

    <!-- Form to Add Worksheet -->
    <fieldset class="border p-4 rounded">
		<legend class="w-auto px-3 text-primary"></legend>
		<form action="<?php echo e(route('worksheets.store')); ?>" method="POST" class="mb-4" id="myForm">
			<?php echo csrf_field(); ?>
			
			<div class="row">
				<div class="col-md-3">
					<div class="form-group">
						<label for="date">Date <span class="mandatory">*</span></label>
						<input type="date" name="date" id="date" class="form-control date" required>
					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">
						<label for="status">Project <span class="mandatory">*</span></label>
						<select name="project_id" id="project_id" class="form-select" required>
							<option value="">Please Select</option>
							
							<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($k); ?>"><?php echo e($option); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						  
						<?php $__errorArgs = ['project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback" role="alert">
								<strong><?php echo e($message); ?></strong>
							</span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				
				<div class="col-md-5">
					<div class="form-group">
						<label for="task">Task <span class="mandatory">*</span></label>
						<input type="text" name="task" id="task" class="form-control" placeholder="Task Name" required>
					</div>
				</div>
				<div class="col-md-2">
					<div class="form-group">
						<label for="status">Status <span class="mandatory">*</span></label>
						 <select id="status" name="status" class="form-control" required>
						  <option value="">Please Select</option>
						  <option value="pending">Pending</option>
						  <option value="completed">Completed</option>
						</select>
					</div>
				</div>
			</div>
			
			<div class="form-group">
				<label for="description">In-depth Task Explanation <span class="mandatory">*</span></label>
				<textarea name="description" id="description" class="form-control editor-class" placeholder="Task Description" ></textarea>
			</div>
			
			<br>
			<button type="submit" class="btn btn-success addmytask">Add My Task</button>
		</form>
	</fieldset>
	<br>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Sr.No.</th> 
				<?php if(Auth::user()->role == 'admin'): ?>
					<th>Staff</th>
				<?php endif; ?>
                <th>Project</th>
                <th>Task</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
			<?php if(@$worksheets && count($worksheets) > 0): ?>
				<?php $__currentLoopData = $worksheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worksheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<?php if(Auth::user()->role == 'admin'): ?>
						<td>
							<?php echo e(@$userNameList[$worksheet->user_id]); ?> 
							(<?php echo e(@$userEmailList[$worksheet->user_id]); ?>)
						</td>
					<?php endif; ?> 
					<td><?php echo e(@$projects[$worksheet->project_id]); ?></td>
					<td><?php echo e($worksheet->task); ?></td>
					<td><?php echo e($worksheet->date); ?></td>
					<td><?php echo e(ucfirst($worksheet->status)); ?></td>
					<td>
						<a href="<?php echo e(route('worksheets.show', Crypt::encrypt($worksheet->id))); ?>" class="btn btn-info">View</a>
						<a href="<?php echo e(route('worksheets.edit', Crypt::encrypt($worksheet->id))); ?>" class="btn btn-warning">Update</a>
						<form action="<?php echo e(route('worksheets.destroy', Crypt::encrypt($worksheet->id))); ?>" method="POST" style="display:inline-block;">
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>
							<button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
						</form>
					</td>
				</tr>
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td colspan="10">
						<?php echo e($worksheets->withQueryString()->links('elements.paginater')); ?>

					</td>
				</tr>
			<?php else: ?>
				<tr>
					<td colspan="10">
						<center>No Task Found</center>
					</td>
				</tr>
			<?php endif; ?>
        </tbody>
		
    </table>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/worksheets/index.blade.php ENDPATH**/ ?>