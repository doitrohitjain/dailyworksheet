<?php $__env->startSection('content'); ?>
 <h1>Add Project</h1>
    
<div class="container">
<fieldset class="border p-4 rounded">
	<legend class="w-auto px-3 text-primary">Add Project</legend>
	<form action="<?php echo e(route('projects.store')); ?>" method="POST" class="mb-4" id="myForm">
		<?php echo csrf_field(); ?>
		
		<div class="row"> 
			<div class="col-md-7">
				<div class="form-group">
					<label for="task">Title <span class="mandatory">*</span></label>
					<input type="text" name="title" id="title" class="form-control" placeholder="Title" required>
				</div>
			</div>
		</div>
		
		<div class="form-group">
			<label for="description">In-depth Task Explanation <span class="mandatory">*</span></label>
			<textarea name="description" id="description" class="form-control editor-class" placeholder="Task Description" ></textarea>
		</div>
		
		<br>
		<button type="submit" class="btn btn-success addmytask">Add Project</button>
	</form>
</fieldset>
</div>

<?php $__env->stopSection(); ?>

 
 
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/projects/create.blade.php ENDPATH**/ ?>