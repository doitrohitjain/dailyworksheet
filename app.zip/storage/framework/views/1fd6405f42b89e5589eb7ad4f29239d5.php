<?php if($paginator->hasPages()): ?>
<nav aria-label="Page navigation example" class="">
    <ul class="horizontal-list">
            <li class="page-item disabled">
                <span style="font-weight:bold;">&nbsp;&nbsp;&nbsp;Records :-<?php echo e($paginator->firstItem()); ?> - <?php echo e($paginator->lastItem()); ?> &nbsp;Total:- <?php echo e($paginator->total()); ?> </span>
            </li>
	
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled">
                <a class="page-link" href="#" tabindex="-1">Previous</a>
            </li>
        <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>">Previous</a></li>
        <?php endif; ?>
		
		<?php $i=0; ?>
		<?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(is_string($element)): ?>
                <li class="page-item disabled"><?php echo e($element); ?></li>
            <?php endif; ?>
            <?php if(is_array($element)): ?>
				<?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <?php if($page == $paginator->currentPage()): ?>
                        <li class="page-item active">
                            <a class="page-link"><?php echo e($page); ?></a>
                        </li>
                    <?php else: ?>
						<?php // if($i!=3 && $i!=3 && $i!=5){ ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
						<?php // }	$i++; ?>
                    <?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
        <?php if($paginator->hasMorePages()): ?>
            <li class="page-item ">
                <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Next</a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <a class="page-link" href="#">Next</a>
            </li>
            
        <?php endif; ?>
    </ul>
 <?php else: ?>
    <nav aria-label="Page navigation example">
    <ul class="">
        <li class="page-item disabled">
        <span style="font-weight:bold;">&nbsp;&nbsp;&nbsp;Records :-<?php echo e($paginator->firstItem()); ?> - <?php echo e($paginator->lastItem()); ?> &nbsp;Total:- <?php echo e($paginator->total()); ?> </span>
    </li>
</ul>
</nav>

<?php endif; ?>
<?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/elements/paginater.blade.php ENDPATH**/ ?>