<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Update Worksheet</h1>
    <form action="<?php echo e(route('worksheets.update', Crypt::encrypt($worksheet->id))); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
		<div class="row">
			<div class="col-md-3">
				<div class="form-group">
					<label for="date">Date <span class="mandatory">*</span></label>
					<input type="date" name="date" id="date" class="form-control date" value="<?php echo e(old('date', $worksheet->date)); ?>" required>
				</div>
			</div>
			<div class="col-md-2">
				<div class="form-group">
					<label for="status">Project <span class="mandatory">*</span></label>
					<select name="project_id" id="project_id" class="form-select" required>
						<option value="">Please Select</option>
						<?php $__currentLoopData = @$projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($k); ?>" <?php echo e($worksheet->project_id === $k ? 'selected' : ''); ?>><?php echo e($option); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					  
					<?php $__errorArgs = ['project_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($message); ?></strong>
						</span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="col-md-2">
				 <div class="form-group">
					<label for="status" class="form-label">Status</label>
					<select name="status" id="status" class="form-control" required>
						<option value="">Please Select</option>
						<option value="pending" <?php echo e($worksheet->status === 'pending' ? 'selected' : ''); ?>>Pending</option>
						<option value="completed" <?php echo e($worksheet->status === 'completed' ? 'selected' : ''); ?>>Completed</option>
					</select>
				</div>
			</div>
			<div class="col-md-5">
				<div class="form-group">
					<label for="task">Task <span class="mandatory">*</span></label>
					<input type="text" name="task" id="task" class="form-control" value="<?php echo e(old('task', $worksheet->task)); ?>" required>
				</div>
			</div>
		</div>
		
        <div class="mb-3">
            <label for="description">In-depth Task Explanation <span class="mandatory">*</span></label>
			<textarea name="description" id="description" class="form-control editor-class"><?php echo e(old('description', $worksheet->description)); ?></textarea>
        </div>
		
       

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/worksheets/edit.blade.php ENDPATH**/ ?>