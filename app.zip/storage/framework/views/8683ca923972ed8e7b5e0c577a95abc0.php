<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Worksheet Details</h1>
    <p><strong>Task Date:</strong> <?php echo e($worksheet->date); ?></p>
    <p><strong>Task Name:</strong> <?php echo e($worksheet->task); ?></p>
    <p><strong>Project Name:</strong> <?php echo e(@$projects[$worksheet->project_id]); ?></p>
    <p>
		
		<strong>Description: </strong> 
		<?php echo e($worksheet->description); ?>

		<div id="rawHtmlContent"></div> 
	</p>
    <p><strong>Status:</strong> <?php echo e(ucfirst($worksheet->status)); ?></p>
    <a href="<?php echo e(route('worksheets.edit', Crypt::encrypt($worksheet->id))); ?>" class="btn btn-primary">Update</a>
    <form action="<?php echo e(route('worksheets.destroy', Crypt::encrypt($worksheet->id))); ?>" method="POST" style="display:inline-block;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/worksheets/show.blade.php ENDPATH**/ ?>