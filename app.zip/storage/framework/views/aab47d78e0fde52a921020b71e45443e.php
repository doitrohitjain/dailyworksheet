<!DOCTYPE html>
<html>
<head>
    <title>Routes List</title>
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Routes List</h1>
    <table>
        <thead>
            <tr>
                <th>URI</th>
                <th>Name</th>
                <th>Method</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($route['uri']); ?></td>
                    <td><?php echo e($route['name'] ?? '-'); ?></td>
                    <td><?php echo e($route['method']); ?></td>
                    <td><?php echo e($route['action']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/routes/routes.blade.php ENDPATH**/ ?>