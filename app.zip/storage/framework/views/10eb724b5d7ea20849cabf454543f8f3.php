<?php $__env->startSection('content'); ?>
	<div class="container">
		<h1>
			Projects <a href="<?php echo e(route('projects.create')); ?>" class='btn btn-primary'>Create New Project</a>
		</h1> 
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Sr.No.</th> 
					<th>Title</th>
					<th>Description</th>
					<th>Status</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				<?php if(@$projects && count($projects) > 0): ?>
					<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($project->title); ?></td>
						<td><?php echo e($project->description); ?></td>
						<td><?php echo e(ucfirst(@$project->status)); ?></td>
						<td>
							<a href="<?php echo e(route('projects.show', Crypt::encrypt($project->id))); ?>" class="btn btn-info">View</a>
							<a href="<?php echo e(route('projects.edit', Crypt::encrypt($project->id))); ?>" class="btn btn-warning">Update</a>
							<form action="<?php echo e(route('projects.destroy', Crypt::encrypt($project->id))); ?>" method="POST" style="display:inline-block;">
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
								<button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
							</form>
						</td>
					</tr> 
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td colspan="10">
							<?php echo e($projects->withQueryString()->links('elements.paginater')); ?>

						</td>
					</tr>
				<?php else: ?>
					<tr>
						<td colspan="10">
							<center>No Project Found</center>
						</td>
					</tr>
				<?php endif; ?>
			</tbody>
			
		</table>
	</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\daily-worksheet-manager\resources\views/projects/index.blade.php ENDPATH**/ ?>