@extends('layouts.app')

@section('content')
 <h1>Update Project</h1>
    <form action="{{ route('projects.update', $project) }}" method="POST">
        @csrf
        @method('PUT')
        <label>Title:</label>
        <input type="text" name="title" value="{{ $project->title }}" required>
        <label>Description:</label>
        <textarea name="description" required>{{ $project->description }}</textarea>
        <button type="submit">Update</button>
    </form>
@endsection
 