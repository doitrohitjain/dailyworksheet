@extends('layouts.app')

@section('content')
	<div class="container">
		<h1>
			Projects <a href="{{ route('projects.create') }}" class='btn btn-primary'>Create New Project</a>
		</h1> 
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>Sr.No.</th> 
					<th>Title</th>
					<th>Description</th>
					<th>Status</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody>
				@if(@$projects && count($projects) > 0)
					@foreach ($projects as $project)
					<tr>
						<td>{{ $loop->iteration }}</td>
						<td>{{ $project->title }}</td>
						<td>{{ $project->description }}</td>
						<td>{{ ucfirst(@$project->status) }}</td>
						<td>
							<a href="{{ route('projects.show', Crypt::encrypt($project->id)) }}" class="btn btn-info">View</a>
							<a href="{{ route('projects.edit', Crypt::encrypt($project->id)) }}" class="btn btn-warning">Update</a>
							<form action="{{ route('projects.destroy', Crypt::encrypt($project->id)) }}" method="POST" style="display:inline-block;">
								@csrf
								@method('DELETE')
								<button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
							</form>
						</td>
					</tr> 
					@endforeach
					<tr>
						<td colspan="10">
							{{ $projects->withQueryString()->links('elements.paginater') }}
						</td>
					</tr>
				@else
					<tr>
						<td colspan="10">
							<center>No Project Found</center>
						</td>
					</tr>
				@endif
			</tbody>
			
		</table>
	</div>
@endsection


