<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
	 
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
		rel="stylesheet">
	<!-- CKEditor 5 Stable CDN -->
	<script src="https://cdn.ckeditor.com/ckeditor5/39.0.2/classic/ckeditor.js"></script>

	
    <!-- Scripts -->
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])
	<link rel="icon" type="image/x-icon" href="/images/logo.png">
	<link href="{{ asset('css/custom.css') }}" rel="stylesheet">
	<script src="{{ asset('js/custom.js') }}"></script>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm headerNav">
            <div class="container">
                <a class="navbar-brand main_menu_navbar_brand" href="{{ url('/') }}">
					<img src="{{ asset('images/logo.png') }}" width="40" height="40" alt="Logo">
					 {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto main_menu_navbar_brand">
                        <!-- Authentication Links --> 
						@guest
							@if(Route::currentRouteName() === 'login')
							@else 
								@if (Route::has('login'))
									<li class="nav-item">
										<a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
									</li>
								@endif
							@endif 
                        @else
							@if (Route::has('dashboard'))
								<li class="nav-item">
									<a class="nav-link mainitem nav-link-active" href="{{ route('dashboard') }}">{{ __('Daily Worksheet') }}</a>
								</li>
							@endif
					 
							@if(auth()->user()->role == 'admin')
								@if (Route::has('employee_register'))
									<li class="nav-item">
										<a class="nav-link mainitem" href="{{ route('employee_register') }}">{{ __('Staff Registration') }}</a>
									</li>
								@endif  
							@endif 
							<li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link mainitem dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                   Reports
                                </a> 
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
									
									@if(Route::has('reports.index'))
										<a class="nav-link" href="{{ route('reports.index') }}">{{ __(' Worksheets Report') }}</a>
									@endif 
									@if(auth()->user()->role == 'admin')
									@if(Route::has('home.employee_listing')) 
										<a class="nav-link " href="{{ route('home.employee_listing') }}">{{ __('Staff Report') }}</a>
									@endif
									@endif
                                </div>
                            </li>
							
						 
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link mainitem dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }}
                                </a> 
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
									<a class="dropdown-item"href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
										{{ ucfirst(Auth::user()->role) }}
									</a> 
									<a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>  
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
		
	 
		<footer class="bg-dark text-white py-5">
			<div class="container">
				<div class="row">
					<!-- Column 1: About -->
					<div class="col-md-8">
						<h5>About Us</h5>
						<p> 
							Welcome to our Daily Worksheet, Employee, and Report Management System! Our platform is designed to streamline your workplace operations, making task management, employee tracking, and reporting easier and more efficient. Whether you're a small business or a growing organization, we provide a user-friendly solution tailored to meet your needs.  
							<br>
							Join us today and experience the future of workplace efficiency! 
						</p>
					</div> 
				   
					<!-- Column 3: Contact -->
					<div class="col-md-4">
						<h5>Contact Us</h5>
						<p>
							<i class="bi bi-geo-alt-fill"></i> IT Building,Yojana Bhawan, Tilak Marg,  <br>
							<i class="bi bi-telephone-fill"></i> C-Scheme Jaipur-302005 (Raj), INDIA  
						</p>
					</div>
				</div>
				<hr class="bg-white">
				<div class="text-center">
					<p class="mb-0">&copy; {{ date("Y") }} Designed, Developed, and Maintained by DOITC. All rights reserved.</p>
				</div>
			</div>
		</footer> 
    </div>
	<style>
		 .mandatory {
		  color: red;
		}
		
	</style>  
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.multiselect').select2({
            placeholder: "Please Select",
            allowClear: true
        });
    });
</script>

<script>
	if (document.querySelector('.editor-class')) {
			let editorInstance;

		// Initialize CKEditor
		ClassicEditor
			.create(document.querySelector('.editor-class'))
			.then(editor => {
				editorInstance = editor;
			})
			.catch(error => {
				console.error(error);
			});

		// jQuery form submission validation
		$('#myForm').on('submit', function (e) {
			// Get CKEditor content
			const content = editorInstance.getData().trim();

			// Check if the content is empty
			if (content === '') {
				e.preventDefault(); // Prevent form submission
				Swal.fire({
					icon: 'error',
					title: 'Validation Error',
					text: 'The In-depth Task Explanation is required!',
				});
			}
		});
	}
</script>
	
	
  <script>
    // Initialize CKEditor for the specific class
    // document.querySelectorAll('.editor-class').forEach(editorElement => {
		// ClassicEditor.create(editorElement)
		// .catch(error => console.error(error));
    // });
	window.onload = function() {
		var today = new Date().toISOString().split('T')[0];
		if (document.querySelector('.date')) {
			document.querySelector('.date').setAttribute("max", today);
			document.querySelector(".date").setAttribute("value", today);
		}

		if (document.querySelector('.end_date')) {
			document.querySelector('.end_date').setAttribute("max", today);
			document.querySelector(".end_date").setAttribute("value", today);
		} 		
	};
	 
  </script>
</body>
</html>
